/*
SC FREE NOT SALE !!
SC FREE NOT SALE !!
SC FREE NOT SALE !!

────────────────────
Base Script By : Lenwy
Recode By : WiL And NotSec
────────────────────
*/
const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')

global.grup = 'https://whatsapp.com/channel/0029VaHn5H6K0IBe0QWnpL11'
global.ig = 'https://instagram.com/story_henzz'
global.thumb = fs.readFileSync("./data/image/thumb.jpg")
global.email = 'henzzxd01@gmail.com'
global.region = 'indonesian'
global.typemenu = 'v4' 
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'Henzz'
global.domain = 'https://store-p.loyncream.my.id'
global.apikey2 = 'ptlc_mgFkepZCiGRhdylqKQIvGdwLlgPPMneb3Jnh6h2fDKJ' // Isi Apikey Pltc Lu
global.capikey2 = 'ptla_6za65qcwF796VPNZ7TbxwY9xz9gghQmPdhgR4pfnwK2'
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.owner = ['6288973686537']

global.keyopenai = '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'
global.ibeng = 'Yl4h5x9wiA'

global.botname = 'LoynBotz 私'
global.packname = 'LoynBotz 私'
global.author = `YouTube: Henzz\nBot: 6288973686537`
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'loyncache'
global.sp = '⭔'
global.anticall = true

global.mess = {
    success: 'Selesai 🫡',
    admin: '🍞 Fitur Khusus Admin Group !',
    botAdmin: '🍞 Fitur Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '🎁 Fitur Khusus Owner !',
    group: '🍞 Fitur Ini Hanya Bisa Digunakan Di Group Chat !',
    private: '🍞 Fitur Ini Hanya Bisa Digunakan Di Private Chat !',
    bot: '🍞 Fitur Khusus Pengguna Nomor Bot !',
    wait: '🍞 *Dalam Proses*',
    endLimit: '🍞 Limit kamu Habis, Limit Akan Direset Setiap Jam 12 !\n\n🍞 *Premium Cuma 2K Permanen* 😋',
    error: '🍞 *Kayaknya Ada Error Nih*',
    prem: '🍞 Fitur Khusus Premium!\n\n🍞 Beli Premium Cuma 5K Permanen',
}

global.limitawal = {
    premium: 9999999999 ,
    free: 50
}

global.multiplier = 1000

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})